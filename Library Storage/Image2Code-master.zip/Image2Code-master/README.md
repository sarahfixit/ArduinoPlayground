# Image2Code
An application to take an image file (jpeg, bmp, etc) and convert it to an array of values 
suitable for including in source code. Source code is in C++ and developed under MS VS2008 
and Emacs. Runs as a GUI app in Windows and a command-line app for *NIX.
